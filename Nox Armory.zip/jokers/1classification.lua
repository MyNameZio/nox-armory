SMODS.Joker{ --Classification
    key = "1classification",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Classification',
        ['text'] = {
            [1] = 'Scored {C:hearts}Hearts{} and {C:diamonds}Diamonds{} become {C:attention}Mult{} cards',
            [2] = 'Scored {C:spades}Spades{} and {C:clubs}Clubs{} become {C:attention}Bonus{} cards'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Hearts") or context.other_card:is_suit("Diamonds") then
                context.other_card:set_ability(G.P_CENTERS.m_mult)
                return {
                    message = "Card Modified!"
                }
            elseif context.other_card:is_suit("Spades") or context.other_card:is_suit("Clubs") then
                context.other_card:set_ability(G.P_CENTERS.m_bonus)
                return {
                    message = "Card Modified!"
                }
            end
        end
    end
}