SMODS.Joker{ --Full Send
    key = "2fullsend",
    config = {
        extra = {
            mult = 5,
            chips = 25,
            dollars = 3,
            dollars2 = 2
        }
    },
    loc_txt = {
        ['name'] = 'Full Send',
        ['text'] = {
            [1] = 'If played hand contains {C:attention}5{} scoring cards',
            [2] = '{C:red}+5{} Mult, {C:blue}+25{} Chips and gain {C:money}$3{}',
            [3] = 'Otherwise, lose {C:money}$2{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if #context.scoring_hand >= 5 then
                return {
                    mult = card.ability.extra.mult,
                    extra = {
                        chips = card.ability.extra.chips,
                        colour = G.C.CHIPS,
                        extra = {
                            dollars = card.ability.extra.dollars,
                            colour = G.C.MONEY
                        }
                        }
                }
            elseif #context.scoring_hand < 5 then
                return {
                    dollars = -card.ability.extra.dollars2
                }
            end
        end
    end
}