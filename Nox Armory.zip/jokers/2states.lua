SMODS.Joker{ --States
    key = "2states",
    config = {
        extra = {
            Multvar = 0,
            Chipsvar = 0
        }
    },
    loc_txt = {
        ['name'] = 'States',
        ['text'] = {
            [1] = '{C:hearts}Light{} suits gives {C:red}+1{} Mult to this Joker',
            [2] = '{C:spades}Dark{} suits gives {C:blue}+5{} Chips to this Joker',
            [3] = '{C:inactive}(Currently{} {C:red}+#1#{} {C:inactive}Mult and{} {C:blue}+#2#{} {C:inactive}Chips){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 8
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.Multvar, card.ability.extra.Chipsvar}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Hearts") or context.other_card:is_suit("Diamonds") then
                card.ability.extra.Multvar = (card.ability.extra.Multvar) + 1
                return {
                    message = "Red!"
                }
            elseif context.other_card:is_suit("Spades") or context.other_card:is_suit("Clubs") then
                card.ability.extra.Chipsvar = (card.ability.extra.Chipsvar) + 5
                return {
                    message = "Blue!"
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    mult = card.ability.extra.Multvar,
                    extra = {
                        chips = card.ability.extra.Chipsvar,
                        colour = G.C.CHIPS
                        }
                }
        end
    end
}