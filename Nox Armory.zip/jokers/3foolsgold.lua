SMODS.Joker{ --Fools Gold
    key = "3foolsgold",
    config = {
        extra = {
            pb_h_x_mult_38bc4752 = 0.25,
            perma_h_x_mult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Fools Gold',
        ['text'] = {
            [1] = 'Scored {C:attention}Gold{} cards permanently',
            [2] = 'gains {X:red,C:white}X0.25{} held in hand Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_gold"] == true then
                context.other_card.ability.perma_h_x_mult = context.other_card.ability.perma_h_x_mult or 0
                context.other_card.ability.perma_h_x_mult = context.other_card.ability.perma_h_x_mult + card.ability.extra.pb_h_x_mult_38bc4752
                return {
                    extra = { message = "Upgrade!", colour = G.C.MULT }, card = card
                }
            end
        end
    end
}