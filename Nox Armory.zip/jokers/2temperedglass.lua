SMODS.Joker{ --Tempered Glass
    key = "2temperedglass",
    config = {
        extra = {
            set_probability = 0,
            numerator = 0
        }
    },
    loc_txt = {
        ['name'] = 'Tempered Glass',
        ['text'] = {
            [1] = '{C:attention}Glass{} cards will not break'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 8
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.fix_probability  then
        local numerator, denominator = context.numerator, context.denominator
            if context.identifier == "glass" then
                numerator = card.ability.extra.set_probability
            end
      return {
        numerator = numerator, 
        denominator = denominator
      }
        end
    end
}