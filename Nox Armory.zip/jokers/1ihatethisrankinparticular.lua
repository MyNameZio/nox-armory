SMODS.Joker{ --I Hate This Rank In Particular
    key = "1ihatethisrankinparticular",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'I Hate This Rank In Particular',
        ['text'] = {
            [1] = 'If scored card is a(n) {C:attention}#1#{} destroy it'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {localize((G.GAME.current_round.rankvar_card or {}).rank or 'Ace', 'ranks')}}
    end,

    set_ability = function(self, card, initial)
        G.GAME.current_round.rankvar_card = { rank = 'Ace', id = 14 }
    end,

    calculate = function(self, card, context)
        if context.setting_blind  then
                if G.playing_cards then
                        local valid_rankvar_cards = {}
                        for _, v in ipairs(G.playing_cards) do
                            if not SMODS.has_no_rank(v) then
                                valid_rankvar_cards[#valid_rankvar_cards + 1] = v
                            end
                        end
                        if valid_rankvar_cards[1] then
                            local rankvar_card = pseudorandom_element(valid_rankvar_cards, pseudoseed('rankvar' .. G.GAME.round_resets.ante))
                            G.GAME.current_round.rankvar_card.rank = rankvar_card.base.value
                            G.GAME.current_round.rankvar_card.id = rankvar_card.base.id
                        end
                    end
        end
        if context.destroy_card and context.destroy_card.should_destroy  then
            return { remove = true }
        end
        if context.individual and context.cardarea == G.play  then
            context.other_card.should_destroy = false
            if context.other_card:get_id() == G.GAME.current_round.rankvar_card.id then
                context.other_card.should_destroy = true
                return {
                    message = "Destroyed!"
                }
            end
        end
    end
}