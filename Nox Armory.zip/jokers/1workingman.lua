SMODS.Joker{ --Workingman
    key = "1workingman",
    config = {
        extra = {
            dollars = 1
        }
    },
    loc_txt = {
        ['name'] = 'Workingman',
        ['text'] = {
            [1] = 'Each played {C:attention}9s{} and {C:attention}5s{}',
            [2] = 'gives {C:gold}$1{} when {C:attention}scored{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 9
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 5 or context.other_card:get_id() == 9) then
                return {
                    dollars = card.ability.extra.dollars
                }
            end
        end
    end
}