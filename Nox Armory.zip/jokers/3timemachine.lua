SMODS.Joker{ --Time Machine
    key = "3timemachine",
    config = {
        extra = {
            clockvar = 0,
            antevar = 1,
            ante_value = 1
        }
    },
    loc_txt = {
        ['name'] = 'Time Machine',
        ['text'] = {
            [1] = '{C:attention}-1{} Ante at end of round after scoring {C:attention}24 Clockwork Cards{}',
            [2] = '{C:inactive}(Works once per ante, currently #1#/24 cards scored){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 9
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.clockvar}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (SMODS.get_enhancements(context.other_card)["m_nx_blaze"] == true and (card.ability.extra.antevar or 0) == 1) then
                card.ability.extra.clockvar = (card.ability.extra.clockvar) + 1
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if ((card.ability.extra.antevar or 0) == 1 and (card.ability.extra.clockvar or 0) >= 24) then
                return {
                    func = function()
                    local mod = -card.ability.extra.ante_value
		ease_ante(mod)
		G.E_MANAGER:add_event(Event({
			func = function()
				G.GAME.round_resets.blind_ante = G.GAME.round_resets.blind_ante + mod
				return true
			end,
		}))
                    return true
                end,
                    message = "Ante -" .. card.ability.extra.ante_value,
                    extra = {
                        func = function()
                    card.ability.extra.clockvar = 0
                    return true
                end,
                        colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.antevar = 0
                    return true
                end,
                            colour = G.C.BLUE
                        }
                        }
                }
            end
        end
        if context.end_of_round and context.main_eval and G.GAME.blind.boss  then
                return {
                    func = function()
                    card.ability.extra.antevar = 1
                    return true
                end
                }
        end
    end
}