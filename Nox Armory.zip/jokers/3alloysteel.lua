SMODS.Joker{ --Alloy Steel
    key = "3alloysteel",
    config = {
        extra = {
            pb_h_dollars_38bc4752 = 2,
            perma_h_dollars = 0
        }
    },
    loc_txt = {
        ['name'] = 'Alloy Steel',
        ['text'] = {
            [1] = 'Scored {C:attention}Steel{} cards permanently',
            [2] = 'gains {C:gold}$2{} bonus at end of round'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_steel"] == true then
                context.other_card.ability.perma_h_dollars = context.other_card.ability.perma_h_dollars or 0
                context.other_card.ability.perma_h_dollars = context.other_card.ability.perma_h_dollars + card.ability.extra.pb_h_dollars_38bc4752
                return {
                    extra = { message = "Upgrade!", colour = G.C.MONEY }, card = card
                }
            end
        end
    end
}