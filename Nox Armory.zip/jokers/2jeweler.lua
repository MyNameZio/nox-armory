SMODS.Joker{ --Jeweler
    key = "2jeweler",
    config = {
        extra = {
            pb_bonus_f8e6f21a = 20,
            pb_mult_8afb049b = 4,
            pb_x_mult_8b86fde6 = 0.05,
            perma_bonus = 0,
            perma_mult = 0,
            perma_x_mult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Jeweler',
        ['text'] = {
            [1] = 'Scored {C:attention}Foil{} cards permanently gains {C:blue}+20{} Chips',
            [2] = 'Scored {C:attention}Holographic{} cards permanently gains {C:red}+4{} Mult',
            [3] = 'Scored {C:attention}Polychrome{} cards permanently gains {X:red,C:white}X0,05{} Mult'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card.edition and context.other_card.edition.key == "e_foil" then
                context.other_card.ability.perma_bonus = context.other_card.ability.perma_bonus or 0
                context.other_card.ability.perma_bonus = context.other_card.ability.perma_bonus + card.ability.extra.pb_bonus_f8e6f21a
                return {
                    extra = { message = localize('k_upgrade_ex'), colour = G.C.CHIPS }, card = card
                }
            elseif context.other_card.edition and context.other_card.edition.key == "e_holo" then
                context.other_card.ability.perma_mult = context.other_card.ability.perma_mult or 0
                context.other_card.ability.perma_mult = context.other_card.ability.perma_mult + card.ability.extra.pb_mult_8afb049b
            elseif context.other_card.edition and context.other_card.edition.key == "e_polychrome" then
                context.other_card.ability.perma_x_mult = context.other_card.ability.perma_x_mult or 0
                context.other_card.ability.perma_x_mult = context.other_card.ability.perma_x_mult + card.ability.extra.pb_x_mult_8b86fde6
            end
        end
    end
}