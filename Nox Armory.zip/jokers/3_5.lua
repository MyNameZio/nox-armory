SMODS.Joker{ --5²
    key = "3_5",
    config = {
        extra = {
            Xmult = 2.5
        }
    },
    loc_txt = {
        ['name'] = '5²',
        ['text'] = {
            [1] = 'If played hand contains {C:attention}exactly 5{} scoring {C:attention}5s{}',
            [2] = 'Each {C:attention}5s {}gives {X:red,C:white}X2.5{} Mult when {C:attention}scored{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.before and context.cardarea == G.jokers  then
            if (function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 5 then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount == 5
end)() then
                G.GAME.pool_flags.nx_5flag = true
                return {
                    message = "5flag"
                }
            end
        end
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 5 and (G.GAME.pool_flags.nx_5flag or false)) then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
    end
}