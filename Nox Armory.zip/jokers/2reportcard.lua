SMODS.Joker{ --Report Card
    key = "2reportcard",
    config = {
        extra = {
            odds = 2,
            levels = 1
        }
    },
    loc_txt = {
        ['name'] = 'Report Card',
        ['text'] = {
            [1] = '{C:attention}10s{} held in hand has a {C:green}#1# in #2#{}',
            [2] = 'chance to {C:attention}level up played poker hand{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_nx_2reportcard') 
        return {vars = {new_numerator, new_denominator}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            if context.other_card:get_id() == 10 then
                if SMODS.pseudorandom_probability(card, 'group_0_d168899c', 1, card.ability.extra.odds, 'j_nx_2reportcard', false) then
              target_hand = (context.scoring_name or "High Card")
                        SMODS.calculate_effect({level_up = card.ability.extra.levels,
      level_up_hand = target_hand}, card)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_level_up_ex'), colour = G.C.RED})
          end
            end
        end
    end
}