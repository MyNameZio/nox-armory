SMODS.Joker{ --Blacksmith
    key = "2blacksmith",
    config = {
        extra = {
            steel = 0,
            mult = 1,
            Tarot = 0
        }
    },
    loc_txt = {
        ['name'] = 'Blacksmith',
        ['text'] = {
            [1] = 'If {C:attention}3{} or more {C:attention}Steel{} cards were triggered this round',
            [2] = 'Gain {X:red,C:white}X0.2{} Mult and creates {C:attention}The Chariot{} at end of round',
            [3] = '{C:inactive}(Currently{} {C:attention}#1#{}{C:inactive}/3 triggers and{} {X:red,C:white}X#2#{}{C:inactive} Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.steel, card.ability.extra.mult}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            if SMODS.get_enhancements(context.other_card)["m_steel"] == true then
                return {
                    func = function()
                    card.ability.extra.steel = (card.ability.extra.steel) + 1
                    return true
                end,
                    message = "Upgrade!"
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    Xmult = card.ability.extra.mult
                }
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if (card.ability.extra.steel or 0) >= 3 then
                return {
                    func = function()
                    card.ability.extra.mult = (card.ability.extra.mult) + 0.2
                    return true
                end,
                    extra = {
                        func = function()local created_consumable = false
                if #G.consumeables.cards + G.GAME.consumeable_buffer < G.consumeables.config.card_limit then
                    created_consumable = true
                    G.GAME.consumeable_buffer = G.GAME.consumeable_buffer + 1
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            SMODS.add_card{set = 'Tarot', key = 'c_chariot', key_append = 'joker_forge_tarot'}
                            G.GAME.consumeable_buffer = 0
                            return true
                        end
                    }))
                end
                    if created_consumable then
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_tarot'), colour = G.C.PURPLE})
                    end
                    return true
                end,
                        colour = G.C.PURPLE
                        }
                }
            end
        end
    end
}