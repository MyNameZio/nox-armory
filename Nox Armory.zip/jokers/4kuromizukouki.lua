SMODS.Joker{ --Kuromizu Kouki
    key = "4kuromizukouki",
    config = {
        extra = {
            SteelVar = 1.1
        }
    },
    loc_txt = {
        ['name'] = 'Kuromizu Kouki',
        ['text'] = {
            [1] = '{C:attention}Steel{} cards additionally gives {X:edition,C:white}^#1#{} Chips when held',
            [2] = 'Increases by {X:edition,C:white}^0.01{} for each {C:attention}Steel{} card at end of round'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_bzlegends"] = true },
    soul_pos = {
        x = 2,
        y = 5
    },
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' 
          or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
          )
          and true
      end,

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.SteelVar}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            if SMODS.get_enhancements(context.other_card)["m_steel"] == true then
                return {
                    e_chips = card.ability.extra.SteelVar
                }
            end
        end
        if context.cardarea == G.hand and context.end_of_round  then
            if SMODS.get_enhancements(context.other_card)["m_steel"] == true then
                return {
                    func = function()
                    card.ability.extra.SteelVar = (card.ability.extra.SteelVar) + 0.01
                    return true
                end,
                    message = "Upgrade!"
                }
            end
        end
    end
}