SMODS.Joker{ --Jack of All Trades
    key = "2jackofalltrades",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Jack of All Trades',
        ['text'] = {
            [1] = 'Played {C:attention}Jacks{} gain a random {C:enhanced}Enhancement{},',
            [2] = '{C:attention}Seal{}, and {C:dark_edition}Edition{} when {C:attention}scored{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 11 and not (context.other_card.edition ~= nil)) then
                local random_edition = poll_edition('edit_card_edition', nil, true, true)
                if random_edition then
                    context.other_card:set_edition(random_edition, true)
                end
                return {
                    message = "Jacked!"
                }
            elseif (context.other_card:get_id() == 11 and not (context.other_card.seal ~= nil)) then
                local random_seal = SMODS.poll_seal({mod = 10})
                if random_seal then
                    context.other_card:set_seal(random_seal, true)
                end
                return {
                    message = "Jacked!"
                }
            elseif (context.other_card:get_id() == 11 and not ((function()
        local enhancements = SMODS.get_enhancements(context.other_card)
        for k, v in pairs(enhancements) do
            if v then
                return true
            end
        end
        return false
    end)())) then
                local enhancement_pool = {}
                for _, enhancement in pairs(G.P_CENTER_POOLS.Enhanced) do
                    if enhancement.key ~= 'm_stone' then
                        enhancement_pool[#enhancement_pool + 1] = enhancement
                    end
                end
                local random_enhancement = pseudorandom_element(enhancement_pool, 'edit_card_enhancement')
                context.other_card:set_ability(random_enhancement)
                return {
                    message = "Jacked!"
                }
            end
        end
    end
}