SMODS.Joker{ --Connoisseur
    key = "3connoisseur",
    config = {
        extra = {
            repetitions = 1,
            repetitions2 = 1,
            repetitions3 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Connoisseur',
        ['text'] = {
            [1] = '{C:enhanced}Enhanced{} or {C:dark_edition}Editioned{} cards {C:attention}retriggers{}',
            [2] = 'once when scored or held in hand'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            if ((function()
        local enhancements = SMODS.get_enhancements(context.other_card)
        for k, v in pairs(enhancements) do
            if v then
                return true
            end
        end
        return false
    end)() or context.other_card.edition ~= nil) then
                return {
                    repetitions = card.ability.extra.repetitions,
                    message = localize('k_again_ex')
                }
            end
        end
        if context.repetition and context.cardarea == G.hand and (next(context.card_effects[1]) or #context.card_effects > 1)  then
            if ((function()
        local enhancements = SMODS.get_enhancements(context.other_card)
        for k, v in pairs(enhancements) do
            if v then
                return true
            end
        end
        return false
    end)() or context.other_card.edition ~= nil) then
                return {
                    repetitions = card.ability.extra.repetitions2,
                    message = localize('k_again_ex')
                }
            end
        end
        if context.repetition and context.cardarea == G.hand and (next(context.card_effects[1]) or #context.card_effects > 1)  then
            if ((function()
        local enhancements = SMODS.get_enhancements(context.other_card)
        for k, v in pairs(enhancements) do
            if v then
                return true
            end
        end
        return false
    end)() or context.other_card.edition ~= nil) then
                return {
                    repetitions = card.ability.extra.repetitions3,
                    message = localize('k_again_ex')
                }
            end
        end
    end
}