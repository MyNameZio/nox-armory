SMODS.Joker{ --Endgame Tactic
    key = "3endgametactic",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Endgame Tactic',
        ['text'] = {
            [1] = '{C:purple}Balances {}Chips and Mult if played hand is a',
            [2] = '{C:attention}Five of a Kind{}, {C:attention}Flush Five{}, or a {C:attention}Flush House{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (context.scoring_name == "Flush Five" or context.scoring_name == "Five of a Kind" or context.scoring_name == "Flush House") then
                return {
                    balance = true
                }
            end
        end
    end
}