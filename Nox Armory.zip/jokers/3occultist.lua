SMODS.Joker{ --Occultist
    key = "3occultist",
    config = {
        extra = {
            joker_slots = 1,
            slotflag = 0
        }
    },
    loc_txt = {
        ['name'] = 'Occultist',
        ['text'] = {
            [1] = 'If played hand contains a scoring {C:attention}Mult{},',
            [2] = '{C:attention}Bonus{}, {C:attention}Glass{}, {C:attention}Stone{}, and {C:attention}Lucky{} card',
            [3] = '{C:dark_edition}+1{} Joker slot and {C:red}self destructs{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.before and context.cardarea == G.jokers  then
            if ((function()
    local count = 0
    for _, playing_card in pairs(context.scoring_hand or {}) do
        if SMODS.get_enhancements(playing_card)["m_glass"] == true then
            count = count + 1
        end
    end
    return count >= 1
end)() and (function()
    local count = 0
    for _, playing_card in pairs(context.scoring_hand or {}) do
        if SMODS.get_enhancements(playing_card)["m_stone"] == true then
            count = count + 1
        end
    end
    return count >= 1
end)() and (function()
    local count = 0
    for _, playing_card in pairs(context.scoring_hand or {}) do
        if SMODS.get_enhancements(playing_card)["m_mult"] == true then
            count = count + 1
        end
    end
    return count >= 1
end)() and (function()
    local count = 0
    for _, playing_card in pairs(context.scoring_hand or {}) do
        if SMODS.get_enhancements(playing_card)["m_lucky"] == true then
            count = count + 1
        end
    end
    return count >= 1
end)() and (function()
    local count = 0
    for _, playing_card in pairs(context.scoring_hand or {}) do
        if SMODS.get_enhancements(playing_card)["m_bonus"] == true then
            count = count + 1
        end
    end
    return count >= 1
end)()) then
                G.GAME.pool_flags.nx_slotflag = true
                return {
                    message = "slotflag"
                }
            end
        end
        if context.after and context.cardarea == G.jokers  then
            if (G.GAME.pool_flags.nx_slotflag or false) then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.joker_slots).." Joker Slot", colour = G.C.DARK_EDITION})
                G.jokers.config.card_limit = G.jokers.config.card_limit + card.ability.extra.joker_slots
                return true
            end,
                    extra = {
                        func = function()
                card:start_dissolve()
                return true
            end,
                            message = "Destroyed!",
                        colour = G.C.RED
                        }
                }
            end
        end
    end
}