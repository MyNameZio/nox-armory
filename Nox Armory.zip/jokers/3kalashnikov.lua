SMODS.Joker{ --Kalashnikov
    key = "3kalashnikov",
    config = {
        extra = {
            mult = 7,
            chips = 62
        }
    },
    loc_txt = {
        ['name'] = 'Kalashnikov',
        ['text'] = {
            [1] = 'Each played {C:attention}Ace{}, {C:attention}King{}, {C:attention}4{}, and {C:attention}7{}',
            [2] = 'gives {C:red}+7{} Mult and {C:blue}+62{} Chips'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 14 or context.other_card:get_id() == 13 or context.other_card:get_id() == 4 or context.other_card:get_id() == 7) then
                return {
                    mult = card.ability.extra.mult,
                    extra = {
                        chips = card.ability.extra.chips,
                        colour = G.C.CHIPS
                        }
                }
            end
        end
    end
}