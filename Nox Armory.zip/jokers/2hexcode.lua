SMODS.Joker{ --Hexcode
    key = "2hexcode",
    config = {
        extra = {
            repetitions = 1
        }
    },
    loc_txt = {
        ['name'] = 'Hexcode',
        ['text'] = {
            [1] = 'Retrigger scored cards with {C:attention}#1#{} suit',
            [2] = '{C:inactive}(Changes every round){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {localize((G.GAME.current_round.suitvar_card or {}).suit or 'Spades', 'suits_singular')}, colours = {G.C.SUITS[(G.GAME.current_round.suitvar_card or {}).suit or 'Spades']}}
    end,

    set_ability = function(self, card, initial)
        G.GAME.current_round.suitvar_card = { suit = 'Spades' }
    end,

    calculate = function(self, card, context)
        if context.setting_blind  then
                if G.playing_cards then
                    local valid_suitvar_cards = {}
                    for _, v in ipairs(G.playing_cards) do
                        if not SMODS.has_no_suit(v) then
                            valid_suitvar_cards[#valid_suitvar_cards + 1] = v
                        end
                    end
                    if valid_suitvar_cards[1] then
                        local suitvar_card = pseudorandom_element(valid_suitvar_cards, pseudoseed('suitvar' .. G.GAME.round_resets.ante))
                        G.GAME.current_round.suitvar_card.suit = suitvar_card.base.suit
                    end
                end
        end
        if context.repetition and context.cardarea == G.play  then
            if context.other_card:is_suit(G.GAME.current_round.suitvar_card.suit) then
                return {
                    repetitions = card.ability.extra.repetitions,
                    message = localize('k_again_ex')
                }
            end
        end
    end
}