SMODS.Joker{ --Diversity
    key = "2diversity",
    config = {
        extra = {
            Chipsvar = 1
        }
    },
    loc_txt = {
        ['name'] = 'Diversity',
        ['text'] = {
            [1] = 'This Joker gains {X:blue,C:white}X0.05{} Chips when',
            [2] = 'an {C:enhanced}Enhanced{} card is {C:attention}scored{}',
            [3] = '{C:inactive}(Currently{} {X:blue,C:white}X#1#{} {C:inactive}Chips){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.Chipsvar}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (function()
        local enhancements = SMODS.get_enhancements(context.other_card)
        for k, v in pairs(enhancements) do
            if v then
                return true
            end
        end
        return false
    end)() then
                card.ability.extra.Chipsvar = (card.ability.extra.Chipsvar) + 0.05
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    x_chips = card.ability.extra.Chipsvar
                }
        end
    end
}