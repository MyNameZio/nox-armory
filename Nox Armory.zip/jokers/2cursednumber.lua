SMODS.Joker{ --Cursed Number
    key = "2cursednumber",
    config = {
        extra = {
            Tarot = 0
        }
    },
    loc_txt = {
        ['name'] = 'Cursed Number',
        ['text'] = {
            [1] = 'If played hand contains exactly three {C:attention}6s{}',
            [2] = 'creates {C:attention}2{} {C:dark_edition}Negative {}{C:attention}The Devil{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 6 then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount == 3
end)() then
                local created_consumable = true
                G.E_MANAGER:add_event(Event({
                    func = function()
                        SMODS.add_card{set = 'Tarot', key = 'c_devil', edition = 'e_negative', key_append = 'joker_forge_tarot'}
                        return true
                    end
                }))
                local created_consumable = true
                G.E_MANAGER:add_event(Event({
                    func = function()
                        SMODS.add_card{set = 'Tarot', key = 'c_devil', edition = 'e_negative', key_append = 'joker_forge_tarot'}
                        return true
                    end
                }))
                return {
                    message = created_consumable and localize('k_plus_tarot') or nil,
                    extra = {
                        message = created_consumable and localize('k_plus_tarot') or nil,
                        colour = G.C.PURPLE
                        }
                }
            end
        end
    end
}