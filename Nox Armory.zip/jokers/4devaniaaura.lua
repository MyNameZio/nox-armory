SMODS.Joker{ --Devania Aura
    key = "4devaniaaura",
    config = {
        extra = {
            emult = 1.1,
            dollars = 2
        }
    },
    loc_txt = {
        ['name'] = 'Devania Aura',
        ['text'] = {
            [1] = 'Played {C:hearts}Heart{} cards turns into {C:attention}Idol Mark{} cards when scored',
            [2] = '{C:attention}Idol Mark{} cards gives {X:edition,C:white}^1.1{} Mult and {C:gold}2${} when scored'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_bzlegends"] = true },
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' 
          or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
          )
          and true
      end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_suit("Hearts") then
                context.other_card:set_ability(G.P_CENTERS.m_nx_idolmark)
                return {
                    message = "Card Modified!"
                }
            elseif SMODS.get_enhancements(context.other_card)["m_nx_idolmark"] == true then
                return {
                    e_mult = card.ability.extra.emult,
                    extra = {
                        dollars = card.ability.extra.dollars,
                        colour = G.C.MONEY
                        }
                }
            end
        end
    end
}