SMODS.Joker{ --Prospector
    key = "3prospector",
    config = {
        extra = {
            pb_mult_9dd77f7e = 15,
            stone = 0,
            perma_mult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Prospector',
        ['text'] = {
            [1] = 'If played hand contains {C:attention}5{} {C:attention}Stone{} cards',
            [2] = '{C:attention}Stone{} cards gains {C:red}+15{} Mult when {C:attention}scored{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 9,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.before and context.cardarea == G.jokers  then
            if (function()
    local count = 0
    for _, playing_card in pairs(context.full_hand or {}) do
        if SMODS.get_enhancements(playing_card)["m_stone"] == true then
            count = count + 1
        end
    end
    return count >= 5
end)() then
                G.GAME.pool_flags.nx_stone = true
                return {
                    message = "stone"
                }
            end
        end
        if context.individual and context.cardarea == G.play  then
            if (SMODS.get_enhancements(context.other_card)["m_stone"] == true and (G.GAME.pool_flags.nx_stone or false)) then
                context.other_card.ability.perma_mult = context.other_card.ability.perma_mult or 0
                context.other_card.ability.perma_mult = context.other_card.ability.perma_mult + card.ability.extra.pb_mult_9dd77f7e
                return {
                    extra = { message = localize('k_upgrade_ex'), colour = G.C.MULT }, card = card
                }
            end
        end
        if context.after and context.cardarea == G.jokers  then
                G.GAME.pool_flags.nx_stone = false
                return {
                    message = "stone"
                }
        end
    end
}