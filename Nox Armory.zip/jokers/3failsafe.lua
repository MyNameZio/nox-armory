SMODS.Joker{ --Failsafe
    key = "3failsafe",
    config = {
        extra = {
            hands = 1,
            hands2 = 1,
            round = 0,
            permanent = 0
        }
    },
    loc_txt = {
        ['name'] = 'Failsafe',
        ['text'] = {
            [1] = 'Hands are set to {C:attention}1{}',
            [2] = '{C:blue}+1{} Hand at {C:attention}last Hand{} of round'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if G.GAME.current_round.hands_left == 0 then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.hands).." Hand", colour = G.C.GREEN})
                G.GAME.current_round.hands_left = G.GAME.current_round.hands_left + card.ability.extra.hands
                return true
            end
                }
            end
        end
        if context.setting_blind  then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Set to "..tostring(card.ability.extra.hands2).." Hands", colour = G.C.BLUE})
                
        G.GAME.round_resets.hands = card.ability.extra.hands2
        ease_hands_played(card.ability.extra.hands2 - G.GAME.current_round.hands_left)
        
                return true
            end
                }
        end
    end
}