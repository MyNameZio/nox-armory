SMODS.Joker{ --Bribery
    key = "2bribery",
    config = {
        extra = {
            dollars = 5,
            Xmult = 0.5
        }
    },
    loc_txt = {
        ['name'] = 'Bribery',
        ['text'] = {
            [1] = '{C:attention}Last card{} in played hand gives {C:gold}5${}',
            [2] = 'and {X:red,C:white}X0.5{} Mult when scored'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card == context.scoring_hand[#context.scoring_hand] then
                return {
                    dollars = card.ability.extra.dollars,
                    extra = {
                        Xmult = card.ability.extra.Xmult
                        }
                }
            end
        end
    end
}