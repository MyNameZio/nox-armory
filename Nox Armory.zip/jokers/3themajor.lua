SMODS.Joker{ --The Major
    key = "3themajor",
    config = {
        extra = {
            roundvar = 0,
            respect = 0
        }
    },
    loc_txt = {
        ['name'] = 'The Major',
        ['text'] = {
            [1] = 'Creates a {C:legendary}Legendary{} Joker every {C:attention}9{} rounds',
            [2] = '{C:inactive}(Currently  #1#/9 rounds){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 8
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.roundvar}}
    end,

    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
                return {
                    func = function()
                    card.ability.extra.roundvar = (card.ability.extra.roundvar) + 1
                    return true
                end
                }
        end
        if context.setting_blind  then
            if (card.ability.extra.roundvar or 0) >= 9 then
                return {
                    func = function()
            local created_joker = false
    if #G.jokers.cards + G.GAME.joker_buffer < G.jokers.config.card_limit then
        created_joker = true
        G.GAME.joker_buffer = G.GAME.joker_buffer + 1
            G.E_MANAGER:add_event(Event({
                func = function()
                    local joker_card = SMODS.add_card({ set = 'Joker', rarity = 'Legendary' })
                    if joker_card then
                        
                        
                    end
                    G.GAME.joker_buffer = 0
                    return true
                end
            }))
            end
            if created_joker then
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_joker'), colour = G.C.BLUE})
            end
            return true
        end,
                    extra = {
                        func = function()
                    card.ability.extra.roundvar = 0
                    return true
                end,
                        colour = G.C.BLUE
                        }
                }
            end
        end
    end
}