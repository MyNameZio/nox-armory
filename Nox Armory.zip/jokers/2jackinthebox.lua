SMODS.Joker{ --Jack-in-the-Box
    key = "2jackinthebox",
    config = {
        extra = {
            tallyvar = 0,
            odds = 3,
            Xmult = 3
        }
    },
    loc_txt = {
        ['name'] = 'Jack-in-the-Box',
        ['text'] = {
            [1] = '{X:red,C:white}X3{} Mult if played hand contains a scoring {C:attention}Jack{}',
            [2] = 'Has a {C:green}#2# in #3#{} chance to {C:attention}Wind up{} when hand is played',
            [3] = 'If {C:attention}Wind up{} counter reaches {C:attention}3{} after hand finishes scoring',
            [4] = 'Adds {C:attention}3{} random {C:dark_edition}Editioned{} {C:attention}Jacks{} to the deck and {C:red}self destructs{}',
            [5] = '{C:inactive}(Currently #1#/3 Winds){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_nx_2jackinthebox') 
        return {vars = {card.ability.extra.tallyvar, new_numerator, new_denominator}}
    end,

    calculate = function(self, card, context)
        if context.before and context.cardarea == G.jokers  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_5022ce6d', 1, card.ability.extra.odds, 'j_nx_2jackinthebox', false) then
              SMODS.calculate_effect({func = function()
                    card.ability.extra.tallyvar = (card.ability.extra.tallyvar) + 1
                    return true
                end}, card)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Click!", colour = G.C.GREEN})
          end
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
            if (function()
    local rankCount = 0
    for i, c in ipairs(context.scoring_hand) do
        if c:get_id() == 11 then
            rankCount = rankCount + 1
        end
    end
    
    return rankCount >= 1
end)() then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
        if context.after and context.cardarea == G.jokers  then
            if (card.ability.extra.tallyvar or 0) == 3 then
                local card_front = pseudorandom_element({G.P_CARDS.S_J, G.P_CARDS.H_J, G.P_CARDS.D_J, G.P_CARDS.C_J}, pseudoseed('add_card_suit'))
            local new_card = create_playing_card({
                front = card_front,
                center = G.P_CENTERS.c_base
            }, G.discard, true, false, nil, true)
            new_card:set_edition(pseudorandom_element({"e_foil", "e_holo", "e_polychrome", "e_negative"}, pseudoseed('add_card_edition')), true)
            
            G.E_MANAGER:add_event(Event({
                func = function()
                    new_card:start_materialize()
                    G.play:emplace(new_card)
                    return true
                end
            }))
                local card_front = pseudorandom_element({G.P_CARDS.S_J, G.P_CARDS.H_J, G.P_CARDS.D_J, G.P_CARDS.C_J}, pseudoseed('add_card_suit'))
            local new_card = create_playing_card({
                front = card_front,
                center = G.P_CENTERS.c_base
            }, G.discard, true, false, nil, true)
            new_card:set_edition(pseudorandom_element({"e_foil", "e_holo", "e_polychrome", "e_negative"}, pseudoseed('add_card_edition')), true)
            
            G.E_MANAGER:add_event(Event({
                func = function()
                    new_card:start_materialize()
                    G.play:emplace(new_card)
                    return true
                end
            }))
                local card_front = pseudorandom_element({G.P_CARDS.S_J, G.P_CARDS.H_J, G.P_CARDS.D_J, G.P_CARDS.C_J}, pseudoseed('add_card_suit'))
            local new_card = create_playing_card({
                front = card_front,
                center = G.P_CENTERS.c_base
            }, G.discard, true, false, nil, true)
            new_card:set_edition(pseudorandom_element({"e_foil", "e_holo", "e_polychrome", "e_negative"}, pseudoseed('add_card_edition')), true)
            
            G.E_MANAGER:add_event(Event({
                func = function()
                    new_card:start_materialize()
                    G.play:emplace(new_card)
                    return true
                end
            }))
                return {
                    func = function()
                G.E_MANAGER:add_event(Event({
                    func = function()
                        G.deck.config.card_limit = G.deck.config.card_limit + 1
                        return true
                    end
                }))
                draw_card(G.play, G.deck, 90, 'up')
                SMODS.calculate_context({ playing_card_added = true, cards = { new_card } })
            end,
                    message = "Added Card!",
                    extra = {
                        func = function()
                G.E_MANAGER:add_event(Event({
                    func = function()
                        G.deck.config.card_limit = G.deck.config.card_limit + 1
                        return true
                    end
                }))
                draw_card(G.play, G.deck, 90, 'up')
                SMODS.calculate_context({ playing_card_added = true, cards = { new_card } })
            end,
                            message = "Added Card!",
                        colour = G.C.GREEN,
                        extra = {
                            func = function()
                G.E_MANAGER:add_event(Event({
                    func = function()
                        G.deck.config.card_limit = G.deck.config.card_limit + 1
                        return true
                    end
                }))
                draw_card(G.play, G.deck, 90, 'up')
                SMODS.calculate_context({ playing_card_added = true, cards = { new_card } })
            end,
                            message = "Added Card!",
                            colour = G.C.GREEN,
                        extra = {
                            func = function()
                card:start_dissolve()
                return true
            end,
                            message = "Boom!",
                            colour = G.C.RED
                        }
                        }
                        }
                }
            end
        end
    end
}