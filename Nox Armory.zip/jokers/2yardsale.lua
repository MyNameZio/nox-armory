SMODS.Joker{ --Yard Sale
    key = "2yardsale",
    config = {
        extra = {
            cardvar = 1
        }
    },
    loc_txt = {
        ['name'] = 'Yard Sale',
        ['text'] = {
            [1] = 'Gives {C:gold}#1#${} at end of round',
            [2] = 'Increases by {C:gold}1${} for each card sold'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 9
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.cardvar}}
    end,

    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
                return {
                    dollars = card.ability.extra.cardvar,
                    message = "Sold!"
                }
        end
        if context.selling_card  then
                return {
                    func = function()
                    card.ability.extra.cardvar = (card.ability.extra.cardvar) + 1
                    return true
                end
                }
        end
    end
}