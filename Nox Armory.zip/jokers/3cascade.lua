SMODS.Joker{ --Cascade
    key = "3cascade",
    config = {
        extra = {
            Scoredvar = 0
        }
    },
    loc_txt = {
        ['name'] = 'Cascade',
        ['text'] = {
            [1] = '{C:attention}Retrigger{} the last card in played hand',
            [2] = 'by the amount of cards {C:attention}scored{} before it'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            if context.other_card == context.scoring_hand[#context.scoring_hand] then
                return {
                    repetitions = card.ability.extra.Scoredvar,
                    message = localize('k_again_ex')
                }
            end
        end
        if context.individual and context.cardarea == G.play  then
            if not (context.other_card == context.scoring_hand[#context.scoring_hand]) then
                card.ability.extra.Scoredvar = (card.ability.extra.Scoredvar) + 1
                return {
                    message = "+1"
                }
            end
        end
        if context.after and context.cardarea == G.jokers  then
                return {
                    func = function()
                    card.ability.extra.Scoredvar = 0
                    return true
                end
                }
        end
    end
}