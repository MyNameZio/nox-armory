SMODS.Joker{ --Archivist
    key = "2archivist",
    config = {
        extra = {
            currenthandsize = 1
        }
    },
    loc_txt = {
        ['name'] = 'Archivist',
        ['text'] = {
            [1] = '{X:red,C:white}X0.25{} Mult for every {C:attention}Hand size{}',
            [2] = '{C:inactive}(Currently{} {X:red,C:white}X#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.currenthandsize + (((G.hand and G.hand.config.card_limit or 0) or 0)) * 0.25}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    Xmult = card.ability.extra.currenthandsize + ((G.hand and G.hand.config.card_limit or 0)) * 0.25
                }
        end
    end
}