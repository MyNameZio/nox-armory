SMODS.Joker{ --Thalia Symphonia
    key = "4thaliasymphonia",
    config = {
        extra = {
            reduction_value = 2,
            Chipsvar = 1,
            Multvar = 1
        }
    },
    loc_txt = {
        ['name'] = 'Thalia Symphonia',
        ['text'] = {
            [1] = 'Reduces card requirement for making {C:attention}Straights{} and {C:attention}Flushes{} by {C:attention}2',
            [2] = '{}Gains {X:blue,C:white}X0.75{} Chips and {X:red,C:white}X0.75{} Mult if hand contains a {C:attention}Straight Flush{}',
            [3] = '{C:inactive}(Currently{} {X:blue,C:white}X#1#{} {C:inactive}Chips and{} {X:red,C:white}X#2#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 8
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_bzlegends"] = true },
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' 
          or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
          )
          and true
      end,

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.Chipsvar, card.ability.extra.Multvar}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    x_chips = card.ability.extra.Chipsvar,
                    extra = {
                        Xmult = card.ability.extra.Multvar
                        }
                }
        end
        if context.before and context.cardarea == G.jokers  then
            if next(context.poker_hands["Straight Flush"]) then
                return {
                    func = function()
                    card.ability.extra.Chipsvar = (card.ability.extra.Chipsvar) + 0.75
                    return true
                end,
                    message = "Upgrade!",
                    extra = {
                        func = function()
                    card.ability.extra.Multvar = (card.ability.extra.Multvar) + 0.75
                    return true
                end,
                        colour = G.C.GREEN
                        }
                }
            end
        end
    end,

    add_to_deck = function(self, card, from_debuff)
        -- Flush/Straight requirements reduced by 2
    end,

    remove_from_deck = function(self, card, from_debuff)
        -- Flush/Straight requirements restored
    end
}


local smods_four_fingers_ref = SMODS.four_fingers
function SMODS.four_fingers()
    if next(SMODS.find_card("j_nx_4thaliasymphonia")) then
        return 3
    end
    return smods_four_fingers_ref()
end