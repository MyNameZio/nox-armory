SMODS.Joker{ --Omnicard
    key = "3omnicard",
    config = {
        extra = {
            pb_bonus_fa6a8f92 = 5,
            pb_mult_893da2c7 = 1,
            pb_x_mult_69ba8e67 = 0.1,
            pb_p_dollars_0d2d8c3c = 1,
            perma_bonus = 0,
            perma_mult = 0,
            perma_x_mult = 0,
            perma_p_dollars = 0
        }
    },
    loc_txt = {
        ['name'] = 'Omnicard',
        ['text'] = {
            [1] = '{C:attention}Wild{} cards gains a permanent {C:blue}+5{} Chips,',
            [2] = '{C:red}+1{} and {X:red,C:white}X0.1{} Mult, and {C:gold}1${} when scored'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_wild"] == true then
                context.other_card.ability.perma_bonus = context.other_card.ability.perma_bonus or 0
                context.other_card.ability.perma_bonus = context.other_card.ability.perma_bonus + card.ability.extra.pb_bonus_fa6a8f92
                context.other_card.ability.perma_mult = context.other_card.ability.perma_mult or 0
                context.other_card.ability.perma_mult = context.other_card.ability.perma_mult + card.ability.extra.pb_mult_893da2c7
                context.other_card.ability.perma_x_mult = context.other_card.ability.perma_x_mult or 0
                context.other_card.ability.perma_x_mult = context.other_card.ability.perma_x_mult + card.ability.extra.pb_x_mult_69ba8e67
                context.other_card.ability.perma_p_dollars = context.other_card.ability.perma_p_dollars or 0
                context.other_card.ability.perma_p_dollars = context.other_card.ability.perma_p_dollars + card.ability.extra.pb_p_dollars_0d2d8c3c
                return {
                    extra = { message = localize('k_upgrade_ex'), colour = G.C.CHIPS }, card = card
                }
            end
        end
    end
}