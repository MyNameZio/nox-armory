SMODS.Joker{ --Pyromaniac
    key = "2pyromaniac",
    config = {
        extra = {
            a = 0,
            repetitions = 2
        }
    },
    loc_txt = {
        ['name'] = 'Pyromaniac',
        ['text'] = {
            [1] = 'Retrigger scored {C:attention}Blaze{} cards twice'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_nx_blaze"] == true then
                return {
                    repetitions = card.ability.extra.repetitions,
                    message = localize('k_again_ex')
                }
            end
        end
    end
}