SMODS.Joker{ --Father Time
    key = "3fathertime",
    config = {
        extra = {
            repetitions = 1,
            odds = 2
        }
    },
    loc_txt = {
        ['name'] = 'Father Time',
        ['text'] = {
            [1] = 'Cards {C:attention}held in hand{} has a {C:green}#1# in #2#{}',
            [2] = 'chance to turn into {C:attention}Clockwork Cards{}',
            [3] = '{C:attention}Clockwork Cards{} retrigger when held in hand'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_nx_3fathertime') 
        return {vars = {new_numerator, new_denominator}}
    end,

    calculate = function(self, card, context)
        if context.repetition and context.cardarea == G.hand and (next(context.card_effects[1]) or #context.card_effects > 1)  then
            if SMODS.get_enhancements(context.other_card)["m_nx_clockwork"] == true then
                return {
                    repetitions = card.ability.extra.repetitions,
                    message = localize('k_again_ex')
                }
            end
        end
        if context.individual and context.cardarea == G.hand and not context.end_of_round  then
            if not (SMODS.get_enhancements(context.other_card)["m_nx_clockwork"] == true) then
                if SMODS.pseudorandom_probability(card, 'group_0_6ba78e91', 1, card.ability.extra.odds, 'j_nx_3fathertime', false) then
              SMODS.calculate_effect({func = function()
                context.other_card:set_ability(G.P_CENTERS.m_bz_clockwork)
                    end}, card)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Changed!", colour = G.C.BLUE})
          end
            end
        end
    end
}