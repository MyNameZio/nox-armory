SMODS.Joker{ --Prismatic Beam
    key = "3prismaticbeam",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Prismatic Beam',
        ['text'] = {
            [1] = 'Disables {C:attention}Suit-based{} Boss Blinds'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.setting_blind  then
            if (G.GAME.blind.config.blind.key == "bl_goad" or G.GAME.blind.config.blind.key == "bl_club" or G.GAME.blind.config.blind.key == "bl_head" or G.GAME.blind.config.blind.key == "bl_window") then
                return {
                    func = function()
            if G.GAME.blind and G.GAME.blind.boss and not G.GAME.blind.disabled then
                G.E_MANAGER:add_event(Event({
                    func = function()
                        G.GAME.blind:disable()
                        play_sound('timpani')
                        return true
                    end
                }))
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('ph_boss_disabled'), colour = G.C.GREEN})
            end
                    return true
                end
                }
            end
        end
    end
}