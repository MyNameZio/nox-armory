SMODS.Joker{ --Alchemist
    key = "2alchemist",
    config = {
        extra = {
            handsize = 0,
            a = 0,
            f = 0,
            v = 0,
            l = 0,
            hand_size = 1,
            hand_size2 = 1,
            hand_size3 = 1,
            hand_size4 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Alchemist',
        ['text'] = {
            [1] = '{C:attention}+1{} Hand size for each unique {C:attention}Transmutation{} card used',
            [2] = '{C:inactive}(Currently{} {C:attention}+#1#{}{C:inactive} Hand size){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.handsize}}
    end,

    calculate = function(self, card, context)
        if context.using_consumeable  then
            if (context.consumeable and (context.consumeable.ability.set == 'transmutation' or context.consumeable.ability.set == 'transmutation') and context.consumeable.config.center.key == 'c_nx_aurum' and (card.ability.extra.a or 0) == 0) then
                return {
                    func = function()
                    card.ability.extra.a = (card.ability.extra.a) + 1
                    return true
                end,
                    extra = {
                        func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.hand_size).." Hand Size", colour = G.C.BLUE})
                G.hand:change_size(card.ability.extra.hand_size)
                return true
            end,
                        colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.handsize = (card.ability.extra.handsize) + 1
                    return true
                end,
                            colour = G.C.GREEN
                        }
                        }
                }
            elseif (context.consumeable and (context.consumeable.ability.set == 'transmutation' or context.consumeable.ability.set == 'transmutation') and context.consumeable.config.center.key == 'c_nx_ferrum' and (card.ability.extra.f or 0) == 0) then
                return {
                    func = function()
                    card.ability.extra.f = (card.ability.extra.f) + 1
                    return true
                end,
                    extra = {
                        func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.hand_size2).." Hand Size", colour = G.C.BLUE})
                G.hand:change_size(card.ability.extra.hand_size2)
                return true
            end,
                        colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.handsize = (card.ability.extra.handsize) + 1
                    return true
                end,
                            colour = G.C.GREEN
                        }
                        }
                }
            elseif (context.consumeable and (context.consumeable.ability.set == 'transmutation' or context.consumeable.ability.set == 'transmutation') and context.consumeable.config.center.key == 'c_nx_lapis' and (card.ability.extra.l or 0) == 0) then
                return {
                    func = function()
                    card.ability.extra.l = (card.ability.extra.l) + 1
                    return true
                end,
                    extra = {
                        func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.hand_size3).." Hand Size", colour = G.C.BLUE})
                G.hand:change_size(card.ability.extra.hand_size3)
                return true
            end,
                        colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.handsize = (card.ability.extra.handsize) + 1
                    return true
                end,
                            colour = G.C.GREEN
                        }
                        }
                }
            elseif (context.consumeable and (context.consumeable.ability.set == 'transmutation' or context.consumeable.ability.set == 'transmutation') and context.consumeable.config.center.key == 'c_nx_vitrum' and (card.ability.extra.v or 0) == 0) then
                return {
                    func = function()
                    card.ability.extra.v = (card.ability.extra.v) + 1
                    return true
                end,
                    extra = {
                        func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.hand_size4).." Hand Size", colour = G.C.BLUE})
                G.hand:change_size(card.ability.extra.hand_size4)
                return true
            end,
                        colour = G.C.BLUE,
                        extra = {
                            func = function()
                    card.ability.extra.handsize = (card.ability.extra.handsize) + 1
                    return true
                end,
                            colour = G.C.GREEN
                        }
                        }
                }
            end
        end
    end
}