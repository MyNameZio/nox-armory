SMODS.Joker{ --King Me
    key = "3kingme",
    config = {
        extra = {
            kingvar = 0
        }
    },
    loc_txt = {
        ['name'] = 'King Me',
        ['text'] = {
            [1] = 'Turns cards at end of round into {C:attention}Kings {}for every {C:attention}King {}scored this round',
            [2] = '{C:inactive}(Currently{} {C:attention}#1#{}{C:inactive} charges){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.kingvar}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 13 then
                card.ability.extra.kingvar = (card.ability.extra.kingvar) + 1
                return {
                    message = "Tallied!"
                }
            end
        end
        if context.cardarea == G.hand and context.end_of_round  then
            if (not (context.other_card:get_id() == 13) and (card.ability.extra.kingvar or 0) > 0) then
                return {
                    func = function()
                assert(SMODS.change_base(context.other_card, nil, "King"))
                    end,
                    message = "Card Modified!",
                    extra = {
                        func = function()
                    card.ability.extra.kingvar = math.max(0, (card.ability.extra.kingvar) - 1)
                    return true
                end,
                        colour = G.C.RED
                        }
                }
            end
        end
    end
}