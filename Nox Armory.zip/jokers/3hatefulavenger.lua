SMODS.Joker{ --Hateful Avenger
    key = "3hatefulavenger",
    config = {
        extra = {
            multvar = 1
        }
    },
    loc_txt = {
        ['name'] = 'Hateful Avenger',
        ['text'] = {
            [1] = '{X:edition,C:white}^#1#{} Mult when hand is played Increases by',
            [2] = '{X:edition,C:white}^0.02{} when a {C:attention}Blaze Card{} is scored',
            [3] = 'Scored {C:attention}Blaze Cards{} {C:red}loses{} their {C:enhanced}Enhancement{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 4
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.multvar}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_nx_blaze"] == true then
                card.ability.extra.multvar = (card.ability.extra.multvar) + 0.02
                context.other_card:set_ability(G.P_CENTERS.c_base)
                return {
                    message = "Card Modified!"
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    e_mult = card.ability.extra.multvar
                }
        end
    end
}