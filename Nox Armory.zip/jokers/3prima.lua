SMODS.Joker{ --Prima
    key = "3prima",
    config = {
        extra = {
            Xmult = 1.7
        }
    },
    loc_txt = {
        ['name'] = 'Prima',
        ['text'] = {
            [1] = 'Played {C:attention}Aces{}, {C:attention}2s{}, {C:attention}3s{}, {C:attention}5s{}, and {C:attention}7s {}',
            [2] = 'gives {X:red,C:white}X1.7{} Mult when scored'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (context.other_card:get_id() == 2 or context.other_card:get_id() == 3 or context.other_card:get_id() == 5 or context.other_card:get_id() == 7 or context.other_card:get_id() == 14) then
                return {
                    Xmult = card.ability.extra.Xmult
                }
            end
        end
    end
}