SMODS.Joker{ --Timer
    key = "2timer",
    config = {
        extra = {
            currentseconds = 0,
            dollars = 15,
            currentseconds = 0
        }
    },
    loc_txt = {
        ['name'] = 'Timer',
        ['text'] = {
            [1] = '{C:gold}$15{} if Blind is defeated in under {C:attention}15{} seconds',
            [2] = '{C:inactive}(Currently #1# seconds){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 9
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.currentseconds}}
    end,

    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if 15 >= os.date("*t", os.time()).sec then
                return {
                    dollars = card.ability.extra.dollars
                }
            end
        end
        if context.setting_blind  then
                return {
                    func = function()
                    card.ability.extra.currentseconds = 0
                    return true
                end
                }
        end
    end
}