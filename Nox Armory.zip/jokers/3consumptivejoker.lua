SMODS.Joker{ --Consumptive Joker
    key = "3consumptivejoker",
    config = {
        extra = {
            chipsvar = 0
        }
    },
    loc_txt = {
        ['name'] = 'Consumptive Joker',
        ['text'] = {
            [1] = 'This Joker gains {C:blue}+30{} Chips',
            [2] = 'when a {C:attention}Consumable{} is used',
            [3] = '{C:inactive}(Currently{} {C:blue}+#1#{} {C:inactive}Chips){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.chipsvar}}
    end,

    calculate = function(self, card, context)
        if context.using_consumeable  then
                return {
                    func = function()
                    card.ability.extra.chipsvar = (card.ability.extra.chipsvar) + 30
                    return true
                end,
                    message = "Consumed!"
                }
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    chips = card.ability.extra.chipsvar
                }
        end
    end
}