SMODS.Joker{ --Psychedelia
    key = "2psychedelia",
    config = {
        extra = {
            odds = 7
        }
    },
    loc_txt = {
        ['name'] = 'Psychedelia',
        ['text'] = {
            [1] = 'Played cards have a {C:green}#1# in #2#{} chance to gain',
            [2] = '{C:attention}Polychrome{} {C:dark_edition}Edition{} when scored'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_nx_2psychedelia') 
        return {vars = {new_numerator, new_denominator}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_aefee4e4', 1, card.ability.extra.odds, 'j_nx_2psychedelia', false) then
              context.other_card:set_edition("e_polychrome", true)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Tweaked!", colour = G.C.BLUE})
          end
            end
        end
    end
}