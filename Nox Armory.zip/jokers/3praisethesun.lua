SMODS.Joker{ --Praise the Sun
    key = "3praisethesun",
    config = {
        extra = {
            odds = 3,
            dollars = 13
        }
    },
    loc_txt = {
        ['name'] = 'Praise the Sun',
        ['text'] = {
            [1] = '{C:attention}Queens{} held in hand at end of round',
            [2] = 'has a {C:green}#1# in #2#{} chance to give {C:gold}$13{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_nx_3praisethesun') 
        return {vars = {new_numerator, new_denominator}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.hand and context.end_of_round  then
            if context.other_card:get_id() == 12 then
                if SMODS.pseudorandom_probability(card, 'group_0_1f952e9a', 1, card.ability.extra.odds, 'j_nx_3praisethesun', false) then
              SMODS.calculate_effect({dollars = card.ability.extra.dollars}, card)
          end
            end
        end
    end
}