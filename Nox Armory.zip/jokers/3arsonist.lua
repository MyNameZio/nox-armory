SMODS.Joker{ --Arsonist
    key = "3arsonist",
    config = {
        extra = {
            multvar = 1,
            blazeflag = 0
        }
    },
    loc_txt = {
        ['name'] = 'Arsonist',
        ['text'] = {
            [1] = 'When a {C:attention}Full House{} is played',
            [2] = 'Scored cards turn into {C:attention}Blaze{} cards',
            [3] = 'and this Joker gains {X:red,C:white}X0.15{} Mult',
            [4] = '{C:inactive}(Currently{} {X:red,C:white}X#1#{} {C:inactive}Mult){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.multvar}}
    end,

    calculate = function(self, card, context)
        if context.before and context.cardarea == G.jokers  then
            if context.scoring_name == "Full House" then
                G.GAME.pool_flags.nx_blazeflag = true
                return {
                    message = "blazeflag",
                    extra = {
                        func = function()
                    card.ability.extra.multvar = (card.ability.extra.multvar) + 0.15
                    return true
                end,
                        colour = G.C.GREEN
                        }
                }
            end
        end
        if context.individual and context.cardarea == G.play  then
            if (G.GAME.pool_flags.nx_blazeflag or false) then
                context.other_card:set_ability(G.P_CENTERS.m_nx_blaze)
                return {
                    message = "Card Modified!"
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    Xmult = card.ability.extra.multvar
                }
        end
        if context.after and context.cardarea == G.jokers  then
                G.GAME.pool_flags.nx_blazeflag = false
                return {
                    message = "blazeflag"
                }
        end
    end
}