SMODS.Joker{ --Focused Charge
    key = "3focusedcharge",
    config = {
        extra = {
            blind_size = 10,
            ante_value = 1
        }
    },
    loc_txt = {
        ['name'] = 'Focused Charge',
        ['text'] = {
            [1] = 'Reduces {C:attention}Boss Blind{} requirements by {C:attention}90%{}',
            [2] = '{C:attention}-1{} Ante and {C:red}self destructs{} if boss blind',
            [3] = 'is cleared with {C:blue}0{} hands remaining'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 3,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.setting_blind  then
            if G.GAME.blind.boss then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Weakened!", colour = G.C.GREEN})
                G.GAME.blind.chips = G.GAME.blind.chips / card.ability.extra.blind_size
                G.GAME.blind.chip_text = number_format(G.GAME.blind.chips)
                G.HUD_blind:recalculate()
                return true
            end
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if (G.GAME.current_round.hands_left == 0 and G.GAME.blind.boss) then
                return {
                    func = function()
                    local mod = -card.ability.extra.ante_value
		ease_ante(mod)
		G.E_MANAGER:add_event(Event({
			func = function()
				G.GAME.round_resets.blind_ante = G.GAME.round_resets.blind_ante + mod
				return true
			end,
		}))
                    return true
                end,
                    message = "Ante -" .. card.ability.extra.ante_value,
                    extra = {
                        func = function()
                card:start_dissolve()
                return true
            end,
                            message = "Destroyed!",
                        colour = G.C.RED
                        }
                }
            end
        end
    end
}