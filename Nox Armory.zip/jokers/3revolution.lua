SMODS.Joker{ --Revolution
    key = "3revolution",
    config = {
        extra = {
            Multvar = 1.1
        }
    },
    loc_txt = {
        ['name'] = 'Revolution',
        ['text'] = {
            [1] = 'Played {C:attention}non-Face{} cards gives {X:red,C:white}X#1#{} Mult when scored',
            [2] = 'Increase this number by {X:red,C:white}X0.05{} Mult when a {C:attention}Face{} card is {C:attention}discarded{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.Multvar}}
    end,

    calculate = function(self, card, context)
        if context.discard  then
            if (function()
    local rankFound = false
    for i, c in ipairs(context.full_hand) do
        if c:is_face() then
            rankFound = true
            break
        end
    end
    
    return rankFound
end)() then
                return {
                    func = function()
                    card.ability.extra.Multvar = (card.ability.extra.Multvar) + 0.05
                    return true
                end,
                    message = "Upgrade!"
                }
            end
        end
        if context.individual and context.cardarea == G.play  then
            if not (context.other_card:is_face()) then
                return {
                    Xmult = card.ability.extra.Multvar
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
                return {
                    func = function()
                    card.ability.extra.Multvar = 1.1
                    return true
                end
                }
        end
    end
}