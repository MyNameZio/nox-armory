SMODS.Joker{ --Specialized Training
    key = "3specializedtraining",
    config = {
        extra = {
            odds = 2,
            odds2 = 4
        }
    },
    loc_txt = {
        ['name'] = 'Specialized Training',
        ['text'] = {
            [1] = 'Scored {C:attention}Kings {}have a {C:green}#1# in #2#{} chance to turn into {C:attention}Steel{}',
            [2] = 'and a {C:green}#3# in #4#{} chance to gain a {C:attention}Red Seal{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 8
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 8,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        local new_numerator, new_denominator = SMODS.get_probability_vars(card, 1, card.ability.extra.odds, 'j_nx_3specializedtraining')
        local new_numerator2, new_denominator2 = SMODS.get_probability_vars(card, 1, card.ability.extra.odds2, 'j_nx_3specializedtraining')
        return {vars = {new_numerator, new_denominator, new_numerator2, new_denominator2}}
    end,

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:get_id() == 13 then
                if SMODS.pseudorandom_probability(card, 'group_0_d03259ab', 1, card.ability.extra.odds, 'j_nx_3specializedtraining', false) then
              context.other_card:set_ability(G.P_CENTERS.m_steel)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Steeled!", colour = G.C.BLUE})
          end
                if SMODS.pseudorandom_probability(card, 'group_1_244bf014', 1, card.ability.extra.odds2, 'j_nx_3specializedtraining', false) then
              context.other_card:set_seal("Red", true)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Sealed!", colour = G.C.BLUE})
          end
            end
        end
    end
}