SMODS.Joker{ --Mystical Stopwatch
    key = "3mysticalstopwatch",
    config = {
        extra = {
            roundvar = 3,
            ante_value = 1
        }
    },
    loc_txt = {
        ['name'] = 'Mystical Stopwatch',
        ['text'] = {
            [1] = '{C:attention}-1{} Ante when Boss Blind is defeated',
            [2] = 'Lasts up to {C:attention}3{} Antes',
            [3] = '{C:inactive}({}{C:attention}#1#{}{C:inactive}/3 Antes remaining){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 9,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.roundvar}}
    end,

    calculate = function(self, card, context)
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if G.GAME.blind.boss then
                return {
                    func = function()
                    local mod = -card.ability.extra.ante_value
		ease_ante(mod)
		G.E_MANAGER:add_event(Event({
			func = function()
				G.GAME.round_resets.blind_ante = G.GAME.round_resets.blind_ante + mod
				return true
			end,
		}))
                    return true
                end,
                    message = "Reset!",
                    extra = {
                        func = function()
                    card.ability.extra.roundvar = math.max(0, (card.ability.extra.roundvar) - 1)
                    return true
                end,
                        colour = G.C.RED
                        }
                }
            elseif (card.ability.extra.roundvar or 0) == 0 then
                return {
                    func = function()
                card:start_dissolve()
                return true
            end,
                    message = "Destroyed!"
                }
            end
        end
    end
}