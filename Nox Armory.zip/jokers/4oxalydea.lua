SMODS.Joker{ --Oxa Lydea
    key = "4oxalydea",
    config = {
        extra = {
            handsizevar = 0,
            hand_size = 1,
            transmutation = 0
        }
    },
    loc_txt = {
        ['name'] = 'Oxa Lydea',
        ['text'] = {
            [1] = 'Creates a {C:dark_edition}Negative {}{C:attention}Transmutation {}card when Blind is selected',
            [2] = '{C:attention}+1{} Hand size for each {C:attention}Transmutation {}card used',
            [3] = '{C:inactive}(Currently{} {C:attention}+#1#{}{C:inactive} Hand size){}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 6
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 20,
    rarity = 4,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["nx_bzlegends"] = true },
    in_pool = function(self, args)
          return (
          not args 
          or args.source ~= 'sho' 
          or args.source == 'buf' or args.source == 'jud' or args.source == 'rif' or args.source == 'rta' or args.source == 'sou' or args.source == 'uta' or args.source == 'wra'
          )
          and true
      end,

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.handsizevar}}
    end,

    calculate = function(self, card, context)
        if context.setting_blind  then
                return {
                    func = function()local created_consumable = true
                G.E_MANAGER:add_event(Event({
                    func = function()
                        SMODS.add_card{set = 'transmutation', key = nil, edition = 'e_negative', key_append = 'joker_forge_transmutation'}
                        return true
                    end
                }))
                    if created_consumable then
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = localize('k_plus_consumable'), colour = G.C.PURPLE})
                    end
                    return true
                end
                }
        end
        if context.using_consumeable  then
            if context.consumeable and (context.consumeable.ability.set == 'transmutation' or context.consumeable.ability.set == 'transmutation') then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.hand_size).." Hand Size", colour = G.C.BLUE})
                G.hand:change_size(card.ability.extra.hand_size)
                return true
            end,
                    extra = {
                        func = function()
                    card.ability.extra.handsizevar = (card.ability.extra.handsizevar) + 1
                    return true
                end,
                        colour = G.C.GREEN
                        }
                }
            end
        end
    end
}