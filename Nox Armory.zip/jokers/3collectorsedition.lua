SMODS.Joker{ --Collectors Edition
    key = "3collectorsedition",
    config = {
        extra = {
            dollars = 2,
            dollars2 = 3
        }
    },
    loc_txt = {
        ['name'] = 'Collectors Edition',
        ['text'] = {
            [1] = '{C:uncommon}Uncommon{} Jokers gives {C:gold}$2{} when hand is played',
            [2] = '{C:rare}Rare{} Jokers gives {C:gold}$3{} instead'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 8,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.other_joker  then
            if (function()
    return context.other_joker.config.center.rarity == 2
end)() then
                return {
                    dollars = card.ability.extra.dollars
                }
            elseif (function()
    return context.other_joker.config.center.rarity == 3
end)() then
                return {
                    dollars = card.ability.extra.dollars2
                }
            end
        end
    end
}