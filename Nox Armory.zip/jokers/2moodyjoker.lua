SMODS.Joker{ --Moody Joker
    key = "2moodyjoker",
    config = {
        extra = {
            chips_min = 5,
            chips_max = 25,
            mult_min = 2,
            mult_max = 10
        }
    },
    loc_txt = {
        ['name'] = 'Moody Joker',
        ['text'] = {
            [1] = '{C:attention}Scored{} cards gives a random',
            [2] = 'amount of {C:blue}Chips{} and {C:red}Mult{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
                return {
                    chips = pseudorandom('chips_decc91db', card.ability.extra.chips_min, card.ability.extra.chips_max),
                    extra = {
                        mult = pseudorandom('mult_2a3a7375', card.ability.extra.mult_min, card.ability.extra.mult_max)
                        }
                }
        end
    end
}