SMODS.Joker{ --Extended Magazine
    key = "2extendedmagazine",
    config = {
        extra = {
            hand_size = 4,
            hand_size2 = 4
        }
    },
    loc_txt = {
        ['name'] = 'Extended Magazine',
        ['text'] = {
            [1] = '{C:attention}+4{} Hand size in {C:attention}Boss Blinds{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 0,
        y = 3
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.setting_blind  then
            if G.GAME.blind.boss then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.hand_size).." Hand Size", colour = G.C.BLUE})
                G.hand:change_size(card.ability.extra.hand_size)
                return true
            end
                }
            end
        end
        if context.end_of_round and context.main_eval and G.GAME.blind.boss  then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(card.ability.extra.hand_size2).." Hand Size", colour = G.C.RED})
                G.hand:change_size(-card.ability.extra.hand_size2)
                return true
            end
                }
        end
    end
}