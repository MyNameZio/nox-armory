SMODS.Joker{ --Solstice
    key = "3solstice",
    config = {
        extra = {
            levels = 1,
            levels2 = 1
        }
    },
    loc_txt = {
        ['name'] = 'Solstice',
        ['text'] = {
            [1] = 'When a {C:planet}Planet{} card is used',
            [2] = 'level up {C:attention}2{} random poker hands'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 9,
        y = 7
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.using_consumeable  then
            if context.consumeable and context.consumeable.ability.set == 'Planet' then
                available_hands = {}
        for hand, value in pairs(G.GAME.hands) do
          if value.visible and value.level >= to_big(1) then
            table.insert(available_hands, hand)
          end
        end
        target_hand = #available_hands > 0 and pseudorandom_element(available_hands, pseudoseed('level_up_hand')) or "High Card"
                available_hands = {}
        for hand, value in pairs(G.GAME.hands) do
          if value.visible and value.level >= to_big(1) then
            table.insert(available_hands, hand)
          end
        end
        target_hand2 = #available_hands > 0 and pseudorandom_element(available_hands, pseudoseed('level_up_hand')) or "High Card"
                return {
                    level_up = card.ability.extra.levels,
      level_up_hand = target_hand,
                    message = localize('k_level_up_ex'),
                    extra = {
                        level_up = card.ability.extra.levels2,
      level_up_hand = target_hand2,
                            message = localize('k_level_up_ex'),
                        colour = G.C.RED
                        }
                }
            end
        end
    end
}