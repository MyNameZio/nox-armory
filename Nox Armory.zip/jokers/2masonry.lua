SMODS.Joker{ --Masonry
    key = "2masonry",
    config = {
        extra = {
            pb_bonus_fe34f929 = 25,
            perma_bonus = 0
        }
    },
    loc_txt = {
        ['name'] = 'Masonry',
        ['text'] = {
            [1] = 'Played {C:attention}Stone{} cards permanently',
            [2] = 'gains {C:blue}+25{} Chips when {C:attention}scored{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 5,
        y = 5
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 7,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_stone"] == true then
                context.other_card.ability.perma_bonus = context.other_card.ability.perma_bonus or 0
                context.other_card.ability.perma_bonus = context.other_card.ability.perma_bonus + card.ability.extra.pb_bonus_fe34f929
                return {
                    extra = { message = "Stoned!", colour = G.C.CHIPS }, card = card
                }
            end
        end
    end
}