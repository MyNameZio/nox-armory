SMODS.Booster {
    key = 'legends_pack',
    loc_txt = {
        name = "Legends Pack",
        text = {
            "Choose 1 from 3 Legendary Jokers"
        },
        group_name = "Legends Pack"
    },
    config = { extra = 3, choose = 1 },
    cost = 30,
    weight = 0.2,
    atlas = "CustomBoosters",
    pos = { x = 0, y = 0 },
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "Joker",
        rarity = "Legendary",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "nx_legends_pack"
        }
    end,
    particles = function(self)
        -- No particles for joker packs
    end,
}


SMODS.Booster {
    key = 'transmuting_pack',
    loc_txt = {
        name = "Transmuting Pack",
        text = {
            "Choose 1 out of 2 Transmutation cards"
        },
        group_name = "Transmuting Pack"
    },
    config = { extra = 2, choose = 1 },
    cost = 7,
    weight = 0.7,
    atlas = "CustomBoosters",
    pos = { x = 1, y = 0 },
    select_card = "consumeables",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "transmutation",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "nx_transmuting_pack"
        }
    end,
    particles = function(self)
        G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
            timer = 0.015,
            scale = 0.2,
            initialize = true,
            lifespan = 1,
            speed = 1.1,
            padding = -1,
            attach = G.ROOM_ATTACH,
            colours = { G.C.WHITE, lighten(G.C.PURPLE, 0.4), lighten(G.C.PURPLE, 0.2), lighten(G.C.GOLD, 0.2) },
            fill = true
        })
        G.booster_pack_sparkles.fade_alpha = 1
        G.booster_pack_sparkles:fade(1, 0)
    end,
}


SMODS.Booster {
    key = 'transmuting_pack3',
    loc_txt = {
        name = "Transmuting Pack",
        text = {
            "Choose 1 out of 2 Transmutation cards"
        },
        group_name = "Transmuting Pack"
    },
    config = { extra = 2, choose = 1 },
    cost = 7,
    weight = 0.7,
    atlas = "CustomBoosters",
    pos = { x = 2, y = 0 },
    select_card = "consumeables",
    discovered = true,
    loc_vars = function(self, info_queue, card)
        local cfg = (card and card.ability) or self.config
        return {
            vars = { cfg.choose, cfg.extra }
        }
    end,
    create_card = function(self, card, i)
        return {
        set = "transmutation",
            area = G.pack_cards,
            skip_materialize = true,
            soulable = true,
            key_append = "nx_transmuting_pack3"
        }
    end,
    particles = function(self)
        G.booster_pack_sparkles = Particles(1, 1, 0, 0, {
            timer = 0.015,
            scale = 0.2,
            initialize = true,
            lifespan = 1,
            speed = 1.1,
            padding = -1,
            attach = G.ROOM_ATTACH,
            colours = { G.C.WHITE, lighten(G.C.PURPLE, 0.4), lighten(G.C.PURPLE, 0.2), lighten(G.C.GOLD, 0.2) },
            fill = true
        })
        G.booster_pack_sparkles.fade_alpha = 1
        G.booster_pack_sparkles:fade(1, 0)
    end,
}
