SMODS.Enhancement {
    key = 'clockwork',
    pos = { x = 1, y = 0 },
    config = {
        extra = {
            chipvar = 1.25,
            heldvar = 0
        }
    },
    loc_txt = {
        name = 'Clockwork',
        text = {
        [1] = '{X:blue,C:white}X#1#{} Chips',
        [2] = 'Increases by {X:blue,C:white}X0.25{} when {C:attention}scored{}',
        [3] = 'after being held in hand {C:attention}2{} times',
        [4] = '{C:inactive}(Currently #2#/2 times){}'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    weight = 2,
    loc_vars = function(self, info_queue, card)
        return {vars = {}}
    end,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            return { x_chips = card.ability.extra.chipvar }
        end
        if context.cardarea == G.hand and context.main_scoring then
            card.ability.extra.heldvar = (card.ability.extra.heldvar) + 1
            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Tick!", colour = G.C.GREEN})
        end
        if context.main_scoring and context.cardarea == G.play and (card.ability.extra.heldvar or 0) >= 2 then
            card.ability.extra.chipvar = (card.ability.extra.chipvar) + 0.25
            card.ability.extra.heldvar = 0
        end
    end
}