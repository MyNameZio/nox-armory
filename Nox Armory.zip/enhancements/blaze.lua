SMODS.Enhancement {
    key = 'blaze',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            multvar = 1.75
        }
    },
    loc_txt = {
        name = 'Blaze',
        text = {
        [1] = '{X:red,C:white}X#1#{} Mult',
        [2] = '{C:red}Decreases{} by {X:red,C:white}X0.15{} when {C:attention}discarded{}',
        [3] = '{C:inactive}(Will not decrease below{} {X:red,C:white}X1.15{} {C:inactive}Mult){}'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    weight = 2,
    loc_vars = function(self, info_queue, card)
        return {vars = {}}
    end,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            return { x_mult = card.ability.extra.multvar }
        end
        if context.discard and context.other_card == card and (card.ability.extra.multvar or 0) > 1.15 then
            return { func = function()
                    card.ability.extra.multvar = math.max(0, (card.ability.extra.multvar) - 0.15)
                    return true
                end }
        end
    end
}