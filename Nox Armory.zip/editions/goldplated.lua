SMODS.Shader({ key = 'gold', path = 'gold.fs' })

SMODS.Edition {
    key = 'goldplated',
    shader = 'gold',
    config = {
        dollars = 3
    },
    in_shop = true,
    weight = 1,
    extra_cost = 5,
    apply_to_float = false,
    disable_shadow = false,
    disable_base_shader = false,
    loc_txt = {
        name = 'Gold-plated',
        label = 'Gold-plated',
        text = {
        [1] = 'Gives {C:gold}$3{} when{C:attention} triggered{}'
    }
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    get_weight = function(self)
        return G.GAME.edition_rate * self.weight
    end,
  
    calculate = function(self, card, context)
        if context.pre_joker or (context.main_scoring and context.cardarea == G.play) then
            return { dollars = lenient_bignum(card.edition.dollars) }
        end
    end
}