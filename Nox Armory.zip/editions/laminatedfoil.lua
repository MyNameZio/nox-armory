SMODS.Shader({ key = 'laminated', path = 'laminated.fs' })

SMODS.Edition {
    key = 'laminatedfoil',
    shader = 'laminated',
    config = {
        chips = 30,
        chips = 60,
        chips = 90,
        chips = 120,
        chips = 150
    },
    in_shop = true,
    weight = 0.5,
    extra_cost = 4,
    apply_to_float = false,
    badge_colour = HEX('0077FF'),
    disable_shadow = false,
    disable_base_shader = false,
    loc_txt = {
        name = 'Laminated Foil',
        label = 'Laminated Foil',
        text = {
        [1] = 'Gives {C:blue}+30{} Chips {C:attention}times{} the card index in',
        [2] = 'played hand when {C:attention}scored{}, up to {C:blue}+150{} Chips'
    }
    },
    unlocked = true,
    discovered = true,
    no_collection = false,
    get_weight = function(self)
        return G.GAME.edition_rate * self.weight
    end,
  
    calculate = function(self, card, context)
        if context.pre_joker or (context.main_scoring and context.cardarea == G.play) and card == context.scoring_hand[1] then
            return { chips = card.edition.chips }
        end
        if context.pre_joker or (context.main_scoring and context.cardarea == G.play) and card == context.scoring_hand[2] then
            return { chips = card.edition.chips }
        end
        if context.pre_joker or (context.main_scoring and context.cardarea == G.play) and card == context.scoring_hand[3] then
            return { chips = card.edition.chips }
        end
        if context.pre_joker or (context.main_scoring and context.cardarea == G.play) and card == context.scoring_hand[4] then
            return { chips = card.edition.chips }
        end
        if context.pre_joker or (context.main_scoring and context.cardarea == G.play) and card == context.scoring_hand[5] then
            return { chips = card.edition.chips }
        end
    end
}