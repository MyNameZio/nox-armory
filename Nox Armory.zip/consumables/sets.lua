SMODS.ConsumableType {
    key = 'transmutation',
    primary_colour = HEX('d4af37'),
    secondary_colour = HEX('d4af37'),
    collection_rows = { 4, 5 },
    shop_rate = 0.3,
    cards = {
        ['c_nx_aurum'] = true,
        ['c_nx_ferrum'] = true,
        ['c_nx_lapis'] = true,
        ['c_nx_vitrum'] = true
    },
    loc_txt = {
        name = "Transmutation",
        collection = "Transmutation Cards",
    }
}